<?php

$codigoLibro = $_POST['codigoLibro'];
$nombre = $_POST['nombre'];
$editorial = $_POST['editorial'];
$autor = $_POST['autor'];
$genero = $_POST['genero'];
$numeropag = $_POST['numeropag'];
$estado = $_POST['estado'];

$con = mysqli_connect("localhost","root","","biblioteca");
$sql = " UPDATE libro SET nombre = '$nombre', editorial = '$editorial', autor = '$autor', genero = '$genero', numeropag = '$numeropag', estado = '$estado' WHERE codigoLibro like $codigoLibro ";
$rta = mysqli_query($con, $sql);
if(!$rta){
    echo "No se Inserto";
}else{
    header("Location: ../mants/libro.php");
}

?>