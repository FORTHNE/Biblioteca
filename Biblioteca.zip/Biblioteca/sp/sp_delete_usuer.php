<?php

$codigoUsuario = $_GET['codigoUsuario'];

$con = mysqli_connect("localhost","root","","biblioteca");
$sql = " DELETE FROM usuario WHERE codigoUsuario like $codigoUsuario ";
$rta = mysqli_query($con, $sql);
if(!$rta){
    echo "No se Inserto";
}else{
    header("Location: ../mants/usuario.php");
}

?>