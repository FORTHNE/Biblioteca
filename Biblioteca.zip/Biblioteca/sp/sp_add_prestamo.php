<?php

$codigoLibro = $_POST['codigoLibro'];
$codigoUsuario = $_POST['codigoUsuario'];
$fechaDevolucion = $_POST['fechaDevolucion'];

$con = mysqli_connect("localhost","root","","biblioteca");
$sql = "INSERT INTO prestamo(codigoLibro, codigoUsuario, fechaDevolucion) VALUES('$codigoLibro', '$codigoUsuario', '$fechaDevolucion')";
$rta = mysqli_query($con, $sql);
if(!$rta){
    echo "No se Inserto";
}else{
    header("Location: ../mants/prestamo.php");
}

?>