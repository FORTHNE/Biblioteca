<?php

    $codigoUsuario = $_POST['codigoUsuario'];
    $Nombre = $_POST['Nombre'];
    $departamento = $_POST['departamento'];
    $municipio = $_POST['municipio'];
    $status = $_POST['status'];
    $fechaNacimiento = $_POST['fechaNacimiento'];
    $correo = $_POST['correo'];
    $clave = $_POST['clave'];

$con = mysqli_connect("localhost","root","","biblioteca");
$sql = " UPDATE usuario SET Nombre = '$Nombre', departamento = '$departamento', municipio = '$municipio', status = '$status', fechaNacimiento = '$fechaNacimiento', correo = '$correo', clave = '$clave' WHERE codigoUsuario like $codigoUsuario ";
$rta = mysqli_query($con, $sql);
if(!$rta){
    echo "No se Inserto";
}else{
    header("Location: ../mants/usuario.php");
}

?>