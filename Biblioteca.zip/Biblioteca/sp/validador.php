<?php

//configuracion de la conexion a base de datos
require_once '../mants/conexion.php';

session_start();
$correo = $_POST['correo'];
$clave = $_POST['clave'];
$_SESSION['correo']=$correo;

$query = mysqli_query($conexion, "SELECT * FROM usuario WHERE correo = '".$correo."' and clave = '".$clave."'");
$nr = mysqli_num_rows($query);

if($nr == 1)
{
    header("Location:../mants/home.php");
}else{

    echo 'Error! Credenciales Incorrectas.';
}

?>