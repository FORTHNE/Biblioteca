<?php

$nombre = $_POST['nombre'];
$editorial = $_POST['editorial'];
$autor = $_POST['autor'];
$genero = $_POST['genero'];
$numeropag = $_POST['numeropag'];
$estado = $_POST['estado'];

$con = mysqli_connect("localhost","root","","biblioteca");
$sql = "INSERT INTO libro(nombre, editorial, autor, genero, numeropag, estado) VALUES('$nombre', '$editorial', '$autor', '$genero', '$numeropag', '$estado')";
$rta = mysqli_query($con, $sql);
if(!$rta){
    echo "No se Inserto";
}else{
    header("Location: ../mants/libro.php");
}

?>