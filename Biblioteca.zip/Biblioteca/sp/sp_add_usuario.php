<?php

$Nombre = $_POST['Nombre'];
$departamento = $_POST['departamento'];
$municipio = $_POST['municipio'];
$status = $_POST['status'];
$fechaNacimiento = $_POST['fechaNacimiento'];
$correo = $_POST['correo'];
$clave = $_POST['clave'];

$con = mysqli_connect("localhost","root","","biblioteca");
$sql = "INSERT INTO usuario(Nombre, departamento, municipio, status, fechaNacimiento, correo, clave) VALUES('$Nombre', '$departamento', '$municipio', '$status', '$fechaNacimiento', '$correo', '$clave')";
$rta = mysqli_query($con, $sql);
if(!$rta){
    echo "No se Inserto";
}else{
    header("Location: ../mants/usuario.php");
}

?>