<?php

$codigoLibro = $_GET['codigoLibro'];

$con = mysqli_connect("localhost","root","","biblioteca");
$sql = " DELETE FROM libro WHERE codigoLibro like $codigoLibro ";
$rta = mysqli_query($con, $sql);
if(!$rta){
    echo "No se Inserto";
}else{
    header("Location: ../mants/libro.php");
}

?>