<?php

$numeroPedido = $_GET['numeroPedido'];

$con = mysqli_connect("localhost","root","","biblioteca");
$sql = " DELETE FROM prestamo WHERE numeroPedido like $numeroPedido ";
$rta = mysqli_query($con, $sql);
if(!$rta){
    echo "No se Inserto";
}else{
    header("Location: ../mants/prestamo.php");
}

?>