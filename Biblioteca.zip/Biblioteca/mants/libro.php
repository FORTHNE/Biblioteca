<!DOCTYPE html>
<html  lang="es">

<head>
    <title> Libros </title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" />
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" />
</head>

<body>
<?php
session_start();
if($_SESSION['correo']==null && $_SESSION['correo']=='')
{
   header("Location:../index.php");
}
?>
    <!--- MENU --->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <a class="navbar-brand" href="#"> | BIBLIOTECA </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
            aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
            <li class="nav-item">
               <a class="nav-link" href="../mants/home.php">| Home </a>
            </li>
            <li class="nav-item">
               <a class="nav-link" href="../mants/libro.php">| Libros </a>
            </li>
            <li class="nav-item">
               <a class="nav-link" href="../mants/prestamo.php">| Prestamos </a>
            </li>
            <li class="nav-item">
               <a class="nav-link" href="../mants/usuario.php">| Usuarios </a>
            </li>
            <li class="nav-item">
               <a class="nav-link" href="../mants/salir.php">| Cerrar Sesion </a>
            </li>
         </ul>
        </div>
    </nav>

    <!--- YOUR WELCOME --->
   <div class="jumbotron jumbotron-fluid">
      <div class="container">
         <h1 class="display-4"> BIENVENIDO ESTUDIANTE </h1>
         <p class="lead"> 
            Correo: <?php echo $_SESSION['correo']; ?>
         </p>
      </div>
   </div>

    <!--- CUERPO DEL PROYECTO --->
    <div class="container">
    <a href="AddLibro.php" class="btn btn-primary">Nuevo Libro</a>
        <div class="row text-center justify-content-center">
            <div class="col-14">

                <?php 

$conn=mysqli_connect("localhost","root","","biblioteca");

$por_pagina=10;
if(isset($_GET['pagina']))
$pagina=$_GET['pagina'];

else 
{

    $pagina=1;
}


$empieza=($pagina-1) * $por_pagina;
$query="SELECT * FROM libro LIMIT $empieza,$por_pagina";
$result=mysqli_query($conn,$query);

?>

                <br>
                <table class="table table-border table-striped table-hover">
                    <tr>
                        <td>ID</td>
                        <td>Nombre</td>
                        <td>Editorial</td>
                        <td>Autor</td>
                        <td>Genero</td>
                        <td>Numero de Paginas</td>
                        <td>Estado</td>
                        <td>Acciones</td>
                    </tr>

                    <?php 

while($fila=mysqli_fetch_assoc($result))
{

?>

                    <tr>
                        <td>
                            <?php echo $fila['codigoLibro'];?>
                        </td>
                        <td>
                            <?php echo $fila['nombre'];?>
                        </td>
                        <td>
                            <?php echo $fila['editorial'];?>
                        </td>
                        <td>
                            <?php echo $fila['autor'];?>
                        </td>
                        <td>
                            <?php echo $fila['genero'];?>
                        </td>
                        <td>
                            <?php echo $fila['numeropag'];?>
                        </td>
                        <td>
                            <?php echo $fila['estado'];?>
                        </td>
                        <td>
                        <a href="../mants/EditLibro.php?
                                codigoLibro=<?php echo $fila['codigoLibro']?>&
                                nombre=<?php echo $fila['nombre']?> &
                                editorial=<?php echo $fila['editorial']?> &
                                autor=<?php echo $fila['autor']?> &
                                genero=<?php echo $fila['genero']?> &
                                numeropag=<?php echo $fila['numeropag']?> &
                                estado=<?php echo $fila['estado']?> "
                                class="btn btn-primary">Editar</a>
                            <a href="../sp/sp_delete_libro.php?codigoLibro=<?php echo $fila['codigoLibro'] ?>" class="btn btn-danger">Eliminar</a>
                        </td>
                    </tr>

                    <?php 
}

?>


                </table>

                <?php 

$query="SELECT * FROM libro ";
$result=mysqli_query($conn,$query);

$total_registros=mysqli_num_rows($result);
$total_paginas=ceil($total_registros/$por_pagina);

echo"<center><a class='paginacion' href='libro.php?pagina=1'>" .'Anterior'. "</a>";

for($i=1; $i<=$total_paginas; $i++)

{

echo"<a class='paginacion' href='libro.php?pagina=".$i."'> ".$i."</a>";

}

echo"<a class='paginacion' href='libro.php?pagina=$total_paginas'>" .'Siguiente'."</a> </center>";


?>


            </div>
        </div>
    </div>

    <br>
    <!--- FOOTER --->
    <footer class="footer mt-auto py-3 bg-dark">
        <div class="container">
            <span class="text-muted"> Derechos Reservados por Biblioteca 2023 &#169; </span>
        </div>
    </footer>

    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

</body>

</html>