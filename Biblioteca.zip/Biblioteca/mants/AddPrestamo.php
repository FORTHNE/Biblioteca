<!DOCTYPE html>
<html>
<head>
   <title> Nuevo Prestamo de Libro </title>
   <meta name="viewport" content="width=device-width, initial-scale=1" />
   <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" />
   <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" />
</head>
<body>
<?php
session_start();
if($_SESSION['correo']==null && $_SESSION['correo']=='')
{
   header("Location:../index.php");
}
?>
    <!--- MENU --->
   <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
      <a class="navbar-brand" href="#"> | BIBLIOTECA </a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
         <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
            <li class="nav-item">
               <a class="nav-link" href="../mants/home.php">| Home </a>
            </li>
            <li class="nav-item">
               <a class="nav-link" href="../mants/libro.php">| Libros </a>
            </li>
            <li class="nav-item">
               <a class="nav-link" href="../mants/prestamo.php">| Prestamos </a>
            </li>
            <li class="nav-item">
               <a class="nav-link" href="../mants/usuario.php">| Usuarios </a>
            </li>
            <li class="nav-item">
               <a class="nav-link" href="../mants/salir.php">| Cerrar Sesion </a>
            </li>
         </ul>
      </div>
   </nav>
   
   <!--- YOUR WELCOME --->
   <div class="jumbotron jumbotron-fluid">
      <div class="container">
         <h1 class="display-4"> BIENVENIDO ESTUDIANTE </h1>
         <p class="lead"> 
            Correo: <?php echo $_SESSION['correo']; ?>
         </p>
      </div>
   </div>
   
   <!--- CUERPO DEL PROYECTO --->
   <div class="container">
      <div class="row text-center justify-content-center">
            <div class="col-5">

                <h2>ENTREGA DEL LIBRO</h2>
                <hr>
                <BR>
                <form action="../sp/sp_add_prestamo.php" method="POST">
                    <div class="mb-3">
                        <label for="formGroupExampleInput2" class="form-label">Libro Prestado:</label>
                        <select class="form-select" aria-label="Default select example" name="codigoLibro">
                        <option value="">Seleccione...</option>
                            <?php
                                require_once '../mants/conexion.php';
                                $query="SELECT  * FROM libro";
                                $result=mysqli_query($conexion, $query) or die (mysqli_error());
                                while ($row=mysqli_fetch_array($result)){
                                echo '<option value="'.$row['codigoLibro'].'">'.$row['nombre'].'</option>';
                                }
                            ?>
                        </select>
                    </div>    
                    <div class="mb-3">
                        <label for="formGroupExampleInput2" class="form-label">Usuario:</label>
                        <select class="form-select" aria-label="Default select example" name="codigoUsuario">
                        <option value="">Seleccione...</option>
                            <?php
                                require_once '../mants/conexion.php';
                                $query="SELECT  * FROM usuario";
                                $result=mysqli_query($conexion, $query) or die (mysqli_error());
                                while ($row=mysqli_fetch_array($result)){
                                echo '<option value="'.$row['codigoUsuario'].'">'.$row['Nombre'].'</option>';
                                }
                            ?>
                        </select>
                    </div>    
                    <div class="mb-3">
                        <label for="formGroupExampleInput2" class="form-label">Fecha de Entrega:</label>
                        <input type="date" class="form-control" id="clave" name="fechaDevolucion" placeholder="" required>
                    </div>      
                    <button type="submit" class="btn btn-primary">Agregar</button>
                    <a href="usuario.php" class="btn btn-danger">Regresar</a>
                </form> 

            </div>
        </div>
   </div>
   
   <br>
   <!--- FOOTER --->
   <footer class="footer mt-auto py-3 bg-dark">
      <div class="container">
         <span class="text-muted"> Derechos Reservados por Biblioteca 2023 &#169; </span>
      </div>
   </footer>
   
   <script src="js/bootstrap.bundle.min.js"></script>
   <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
   <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
   
</body>
</html>