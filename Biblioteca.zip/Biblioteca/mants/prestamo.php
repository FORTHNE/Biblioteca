<!DOCTYPE html>
<html>
<head>
   <title> Prestamo de Libros </title>
   <meta name="viewport" content="width=device-width, initial-scale=1" />
   <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" />
   <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" />
</head>
<body>
<?php
session_start();
if($_SESSION['correo']==null && $_SESSION['correo']=='')
{
   header("Location:../index.php");
}
?>
    <!--- MENU --->
   <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
      <a class="navbar-brand" href="#"> | BIBLIOTECA </a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
         <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
            <li class="nav-item">
               <a class="nav-link" href="../mants/home.php">| Home </a>
            </li>
            <li class="nav-item">
               <a class="nav-link" href="../mants/libro.php">| Libros </a>
            </li>
            <li class="nav-item">
               <a class="nav-link" href="../mants/prestamo.php">| Prestamos </a>
            </li>
            <li class="nav-item">
               <a class="nav-link" href="../mants/usuario.php">| Usuarios </a>
            </li>
            <li class="nav-item">
               <a class="nav-link" href="../mants/salir.php">| Cerrar Sesion </a>
            </li>
         </ul>
      </div>
   </nav>
   
   <!--- YOUR WELCOME --->
   <div class="jumbotron jumbotron-fluid">
      <div class="container">
         <h1 class="display-4"> BIENVENIDO ESTUDIANTE </h1>
         <p class="lead"> 
            Correo: <?php echo $_SESSION['correo']; ?>
         </p>
      </div>
   </div>
   
   <!--- CUERPO DEL PROYECTO --->
   <div class="container">
   <a href="AddPrestamo.php" class="btn btn-primary">Nuevo Prestamo</a>
      <div class="row text-center justify-content-center">
            <div class="col-12">
            <?php 

$conn=mysqli_connect("localhost","root","","biblioteca");

$por_pagina=10;
if(isset($_GET['pagina']))
$pagina=$_GET['pagina'];

else 
{

    $pagina=1;
}


$empieza=($pagina-1) * $por_pagina;
$query="SELECT p.numeroPedido, l.nombre, u.Nombre, p.fechaSalida, p.fechaDevolucion FROM prestamo p
INNER JOIN usuario u ON u.codigoUsuario=p.codigoUsuario
INNER JOIN libro l ON l.codigoLibro=p.codigoLibro LIMIT $empieza,$por_pagina";
$result=mysqli_query($conn,$query);

?>

                <br>
                <table class="table table-border table-striped table-hover">
                    <tr>
                        <td>N°</td>
                        <td>Libro</td>
                        <td>Usuario</td>
                        <td>Fecha Salida</td>
                        <td>Fecha de Entrega</td>
                        <td>Acciones</td>
                    </tr>

                    <?php 

while($fila=mysqli_fetch_assoc($result))
{

?>

                    <tr>
                        <td>
                            <?php echo $fila['numeroPedido'];?>
                        </td>
                        <td>
                            <?php echo $fila['nombre'];?>
                        </td>
                        <td>
                            <?php echo $fila['Nombre'];?>
                        </td>
                        <td>
                            <?php echo $fila['fechaSalida'];?>
                        </td>
                        <td>
                            <?php echo $fila['fechaDevolucion'];?>
                        </td>
                        <td>
                            <a href="../sp/sp_delete_prestamo.php?numeroPedido=<?php echo $fila['numeroPedido'] ?>" class="btn btn-success">Entregado</a>
                        </td>
                    </tr>

                    <?php 
}

?>


                </table>

                <?php 

$query="SELECT * FROM prestamo ";
$result=mysqli_query($conn,$query);

$total_registros=mysqli_num_rows($result);
$total_paginas=ceil($total_registros/$por_pagina);

echo"<center><a class='paginacion' href='prestamo.php?pagina=1'>" .'Anterior'. "</a>";

for($i=1; $i<=$total_paginas; $i++)

{

echo"<a class='paginacion' href='prestamo.php?pagina=".$i."'> ".$i."</a>";

}

echo"<a class='paginacion' href='prestamo.php?pagina=$total_paginas'>" .'Siguiente'."</a> </center>";


?>
            </div>
        </div>
   </div>
   
   <br>
   <!--- FOOTER --->
   <footer class="footer mt-auto py-3 bg-dark">
      <div class="container">
         <span class="text-muted"> Derechos Reservados por Biblioteca 2023 &#169; </span>
      </div>
   </footer>
   
   <script src="js/bootstrap.bundle.min.js"></script>
   <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
   <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
   
</body>
</html>