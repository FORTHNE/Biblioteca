<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.0.0/animate.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
</head>
<body> 

    <form action="./sp/validador.php" method="post">
        <section class="vh-100" style="background-color: #508bfc;">
        <div class="container py-5 h-100">
          <div class="row d-flex justify-content-center align-items-center h-100">
            <div class="col-12 col-md-8 col-lg-6 col-xl-5">
              <div class="card shadow-2-strong" style="border-radius: 1rem;">
                <div class="card-body p-5 text-center">
      
                  <h3 class="mb-5"> LOGIN </h3>
      
                  <div class="form-outline mb-4">
                    <input type="email" id="username" name="correo" class="form-control form-control-lg" required />
                    <label class="form-label" for="">Correo:</label>
                  </div>
      
                  <div class="form-outline mb-4">
                    <input type="password" id="password" name="clave" class="form-control form-control-lg" required />
                    <label class="form-label" for="">Contraseña:</label>
                  </div>
                  <p id="errorMessage" hidden></p>
                  <button class="btn btn-primary btn-lg btn-block" id="submit" type="submit">Iniciar Sesion</button>

                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </form>

    <script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>